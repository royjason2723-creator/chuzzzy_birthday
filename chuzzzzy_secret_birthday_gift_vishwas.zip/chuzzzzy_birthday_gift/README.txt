# Chuzzzzy's Secret Birthday Gift 🎁

A playful, mobile-friendly birthday surprise site inspired by secret unlock birthday projects.

## Quick start
1. Extract the ZIP.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Enter the PIN `2110` (21 October in DDMM format).

## Personalize before sending
Open `index.html` in Notepad or Visual Studio Code.
Near the bottom, find `const CONFIG = {` and change:
- `recipient`: recipient's display name
- `pin`: secret unlock code
- `sender`: your name
- `giftMessages`: the three gift messages
- `letter`: the birthday letter

Also search for `YOUR NAME` if you want to change the visible placeholder in the on-page letter.

## Add photos
The three memory cards currently use emoji placeholders. To use photos:
1. Create a folder named `photos` beside `index.html`.
2. Put three image files in it, e.g. `memory1.jpg`, `memory2.jpg`, `memory3.jpg`.
3. In each `.photo` card, replace `<div class="placeholder">...</div>` with:
   `<img src="photos/memory1.jpg" alt="A favourite memory" style="width:100%;height:105px;object-fit:cover;border-radius:4px">`
   Repeat with the other filenames for the other cards.
4. Keep only photos you're comfortable sharing in a public website.

## Publish it free with GitHub Pages
1. Sign in at https://github.com and create a new repository, e.g. `chuzzzzy-birthday`.
2. Upload `index.html` (and your `photos` folder if you added photos).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait a few minutes; GitHub will show your live website URL in Pages settings.
7. Open the URL on your phone to test it before sending it.

## Important
The PIN is only a fun gate, not real security: the PIN is visible in the source code. Anyone with access to the public site can inspect it. Avoid uploading private photos or sensitive information to a public repository. This website does not collect or send anyone's data.
